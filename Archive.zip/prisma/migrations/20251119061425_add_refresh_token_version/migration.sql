-- AlterTable
ALTER TABLE "UserWallet" ADD COLUMN     "refreshTokenVersion" INTEGER NOT NULL DEFAULT 0;
